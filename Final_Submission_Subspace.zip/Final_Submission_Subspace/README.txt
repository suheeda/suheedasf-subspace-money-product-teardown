SUBSPACE.MONEY — PRODUCT TEARDOWN SUBMISSION
Product Intern Assignment 2026 | Deadline: 31 May 2026 23:59 IST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FOLDER STRUCTURE
  01_Reports/
    Subspace_Product_Teardown_Report.docx   Full teardown report (Word)
    Subspace_Product_Teardown.pdf            Full teardown report (PDF)

  02_Presentation/
    Subspace_Product_Teardown.pptx           12-slide presentation deck

  03_Frameworks/
    SWOT_Analysis.txt                        SWOT breakdown
    Competitor_Analysis.txt                  Feature comparison matrix

  Executive_Summary.txt                      Quick-read summary of all 5 insights
  README.txt                                 This file

HOW TO READ
  Start with Executive_Summary.txt for a 2-minute overview.
  Read the PDF or DOCX for full insight depth (Observed/Problem/Ship format).
  Use the PPTX for presenting to a panel or walkthrough.

COMPANY SELECTED: Subspace.money
REASON: Consumer fintech with genuine moats (Negotiate API, group-sharing network
        effects, India-first local marketplace) but clear, high-impact product gaps
        that can be shipped immediately. The group admin trust issue (P0) is
        especially urgent — it directly erodes the core flywheel.

METHODOLOGY
  1. Explored subspace.money web app and Play Store listing as a real user
  2. Read 3,200+ Play Store reviews, analysed recurring complaint themes
  3. Competitor research: Woohoo, myPaisaa, Paytm Subs, MoneyClub
  4. Market sizing: RedSeer 2024 corporate gifting report, ONDC seller data
  5. Frameworks used: SWOT, Porter's Five Forces (implicit), ICPs analysis
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
